#ifndef __I2C_EE_H
#define __I2C_EE_H
#include "stm32f10x_i2c.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "sys.h"
#include "usart.h"
void I2C_init(void);
void I2C_Byte_Write(u8 slaveaddr,u8 p,u8 addr);
void I2C_BufferRead(u8 slaveaddr,u8 *p,u8 addr,u16 len);
#endif
