#ifndef __MPU6050_H
#define __MPU6050_H
#include "i2c.h"
#include "math.h"
#define MPU6050_ADDR 0XD0
#define MPU6050_POWER_ADDR 0X6B
#define MPU6050_POWER2_ADDR 0X6C
#define MPU6050_GYRO_ADDR 0X1B
#define MPU6050_ACC_ADDR 0X1C
#define MPU6050_INT_ADDR 0X38
#define MPU6050_USER_ADDR 0X6A
#define MPU6050_FIFO 0X23
#define MPU6050_DLPF 0X1A
#define SMPLRT_DIV 0X19
#define Kp 100.0f 
#define Ki 0.002f                       
#define halfT 0.001f

struct Acc{
	short acc_x;
	short acc_y;
	short acc_z;
};
typedef struct Acc Acc_TypeDef;
struct Gypo{
	short gypo_x;
	short gypo_y;
	short gypo_z;
};
typedef struct Gypo Gypo_TypeDef;
struct Quaternion{
	float w,x,y,z;
};
typedef struct Quaternion Quaternion_TypeDef;
void Mpu_Init(void);
void Mpu_GetData(Gypo_TypeDef *gypo,Acc_TypeDef *acc);
void Charge(Acc_TypeDef *p1,Gypo_TypeDef *p2,float *p3,float *p4);

#endif
